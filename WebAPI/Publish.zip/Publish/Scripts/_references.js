﻿//Add JS/CSS references here to enable intellisense from external packages.
/// <reference path="~/bower_components/jquery/dist/jquery.js" />
/// <reference path="~/bower_components/bootstrap/dist/js/bootstrap.js" />
/// <reference path="~/bower_components/angular/angular.js" />
/// <reference path="~/bower_components/angular-route/angular-route.js" />
/// <reference path="~/bower_components/bootstrap/dist/css/bootstrap.css"/>