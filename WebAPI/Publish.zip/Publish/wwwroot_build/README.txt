Fill out publish\config.json with your IIS app settings to enable the gulp task 04-deploy-app

For more information on using gulp-msdeploy, see https://www.npmjs.org/package/gulp-msdeploy

Also see 'Simple Deployments to AWS with WebDeploy' article on the ServiceStack wiki. https://github.com/ServiceStack/ServiceStack/wiki/Simple-Deployments-to-AWS-with-WebDeploy